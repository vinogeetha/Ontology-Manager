function drawGraph(graphId, datafileName){

var svg = d3.select("#"+graphId),
	width = +svg.attr("width"),
	height = +svg.attr("height");


var color = d3.scaleOrdinal(d3.schemeCategory20);

var simulation = d3.forceSimulation()
	.force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
	.force("collision", d3.forceCollide().radius(30))
	.force("gravity",d3.forceManyBody().strength(30))
	.force("center", d3.forceCenter(width/ 2, height / 2));

d3.json(datafileName, function(error,graph1) {
	if(error) throw error;

	var nodes_display = graph1.nodes;
	var links_display = graph1.links;
	var ok = [];
	var flag = 0;
	var array = [];var src_array = [];var obj_array = [];
	var length = 0;
	var sub_obj = "OBJECT";
	var groupOfLinksAndNodes = svg.append("g");
	var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
	var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
	var groupOfNodeElements = groupOfNodes.selectAll("g").data(graph1.nodes).enter().append("g")

	.on("click", function(d,i){

		d3.select(this).select("circle").transition()
        .duration(750)
        // .attr("r", 36)
        .style("fill", "white")
				.style("stroke", "black")


		ok = [];
		length=d.id.length; //node length
		for(i=0;i<links_display.length;i++){
			array = links_display[i].id;
			src_array =array.slice(0,length);
			if(d.id ==src_array){
				sub_obj = "SUBJECT";
				break;
			}
				else {
					sub_obj = "OBJECT";
				}
	}
	for(i=0;i<links_display.length;i++){
		array = links_display[i].id;
		src_array =array.slice(0,length);
		if(d.id ==src_array){
			ok.push(links_display[i]);
		}

}
			document.getElementById('para').innerHTML = "";
			if(flag!=0)
			for(i=0;i<ok.length;i++){
				var parent = document.getElementById("divpara1");
				parent.innerHTML = "";
			}
				para = document.createElement("h4");
				node = document.createTextNode(ok[0].source.id+ " " +' \''+ok[0].relation+' \''+" " );
				para.appendChild(node);
				element = document.getElementById("divpara1");
				element.appendChild(para);

		for(i=0;i<ok.length;i++){

			para1 = document.createElement("li");
			node1 = document.createTextNode(ok[i].target.id);
			para1.appendChild(node1);

			  element = document.getElementById("divpara1");
				element.appendChild(para1);

				element1 = document.getElementById("divpara");
				element1.appendChild(element);
				flag++;
			}
		})
					.call(d3.drag()
					.on("start", dragstarted)
					.on("drag", dragged)
					.on("end", dragended)
					)

	groupOfNodeElements.append("circle")
		.attr("r", 30)
		.attr("fill", function(d) { return color(d.group); })
	groupOfNodeElements.append("text")
		.text(function(d) {return d.id;});

	var link = groupLinks
		.selectAll("path")
		.data(graph1.links)
		.enter().append("path")

		simulation
			.nodes(graph1.nodes)
			.on("tick", ticked);
		simulation
			.force("link")
			.links(graph1.links)
	var nodeLabels = groupOfNodes
		.selectAll("text")
		.data(graph1.nodes)
		.enter().append("text")
		.text(function(d) { return d.value; })
		.attr("text-anchor","middle")
	// var linkLabels = groupLinks
	// 	.selectAll("text")
	// 	.data(graph1.links)
	// 	.enter().append("text")
	// 	.text(function(d) { return d.relation })
	// 	.attr("text-anchor","middle")

		function ticked() {

			link.attr("d", function(d) {
				dx = d.target.x - d.source.x;
				dy = d.target.y - d.source.y;
				dr = Math.sqrt(dx*dx + dy*dy);
				return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
			})


		// link
		// 	.attr("x1", function(d) {return d.source.x;})
		// 	.attr("y1", function(d) {return d.source.y;})
		// 	.attr("x2", function(d) {return d.target.x;})
		// 	.attr("y2", function(d) {return d.target.y;})
		groupOfNodes
			.selectAll("circle")
			.attr("cx", function(d) {return d.x;})
			.attr("cy", function(d) {return d.y;})
		groupOfNodes
			.selectAll("text")
			.attr("x", function(d) { return d.x - 20 })
			.attr("y", function(d) { return d.y; });
		// linkLabels
		// 	.attr("x", function(d) { return (d.source.x + d.target.x) / 2; })
		// 	.attr("y", function(d) { return (d.source.y + d.target.y) / 2; })
		nodeLabels
			.attr("x",function(d) {return d.x})
			.attr("y",function(d) {return d.y})
	}
});

//graphone

function dragstarted(d) {
	if (!d3.event.active) simulation.alphaTarget(0.3).restart();
	d.fx = d.x;
	d.fy = d.y;
}

function dragged(d) {
	d.fx = d3.event.x;
	d.fy = d3.event.y;
}

function dragended(d) {
	// if (!d3.event.active) simulation.alphaTarget(0);
	// d.fx = null;
	// d.fy = null;
	d.fixed = true;
	// simulation.restart();
}
}
