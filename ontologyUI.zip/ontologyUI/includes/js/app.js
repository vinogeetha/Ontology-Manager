var mindMap = angular.module('mindMap',['ngMaterial']);



mindMap.factory('GetNameService', function ($http,$q)
{
    return {
        getName: function(str) {
            // the $http API is based on the deferred/promise APIs exposed by the $q service
            // so it returns a promise for us by default
    var url = "http://localhost:4000/nodes?id_like="+str;
            return $http.get(url)
                .then(function(response) {
                    if (typeof response.data === 'object') {
                        return response.data;``
                    } else {
                        // invalid response
                        return $q.reject(response.data);
                    }
                }, function(response) {
                    // something went wrong
                    return $q.reject(response.data);
                });
        }
    };
});


mindMap.controller('graphCtrl', function($scope, $mdDialog, $rootScope, $http,GetNameService) {
    $scope.searchText = "";
    $scope.display_msg = " ";
      $scope.shows = true;
      $scope.searchGraphShow = false;
    $scope.alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    $scope.display1 = "";
    $scope.Person = [];
    $scope.selectedItem = [];
    $scope.isDisabled = false;
    $scope.noCache = false;
    $scope.show = false;
    $scope.show1 = false;
    $scope.showsearch=false;
    $scope.msg = "";
    $scope.flag=0;
    $scope.index=[];
    $scope.filter_show = true;
    $scope.data1 = {"nodes":[{"id":"eee"},{"id":"fff"}],"links":[{"source":"eee","target":"fff","id":"eeefff","value":"1"}]};
    $scope.data = {};

    var a=b=c=0;
    $scope.selectedItemChange = function (item) {
        if ($scope.selectedItem){
          $scope.text=$scope.selectedItem.id;
          console.log($scope.text);
        }
      }

    $scope.searchTextChange = function (str) {
  return GetNameService.getName(str);
    }

    $scope.showTabDialog = function(ev) {
    $mdDialog.show({
     controller:  'DialogController',
     templateUrl: 'includes/views/tab.html',
     parent: angular.element(document.body),
     targetEvent: ev,
     clickOutsideToClose: true
    })};

    $http.get('http://localhost:4000/nodes')
               .success(function (data, status, headers, config) {
                  $scope.data.nodes = data;
                   //console.log($scope.data.nodes);
               });

     $http.get('http://localhost:4000/links')
                .success(function (data, status, headers, config) {
                   $scope.data.links = data;
                    //console.log($scope.data.links);
                });


$scope.graph = function(){
$scope.searchGraphShow = true;
$scope.shows1 = false;
$scope.shows = true;
$scope.graph2_show = true;
  for(i=0;i<$scope.data.nodes.length;i++)
  {
    if($scope.text.toLowerCase()==($scope.data.nodes[i].id.toLowerCase() ))
    {
      $scope.grp=$scope.data.nodes[i].group;
    }//if_end
  }//for_end
      $http.get('http://localhost:4000/nodes?group='+$scope.grp)
       .success(function (data, status, headers, config) {

            $scope.data1.nodes = data;


             });
      $http.get('http://localhost:4000/links?id_like='+$scope.text)
        .success(function (data, status, headers, config) {
          $scope.data1.links = data;



  var foo = d3.select("#graph");
  foo.remove();

  var svg = d3.select("#searchedGraph"),
	width = +svg.attr("width"),
	height = +svg.attr("height");


  var color = d3.scaleOrdinal(d3.schemeCategory20);

var simulation = d3.forceSimulation()
	.force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
	.force("collision", d3.forceCollide().radius(30))
	.force("gravity",d3.forceManyBody().strength(30))
	.force("center", d3.forceCenter(width/ 2, height / 2));
  var nodes_display = $scope.data1.nodes;
	var links_display = $scope.data1.links;
	var ok = [];
	var flag = 0;
	var array = [];var src_array = [];var obj_array = [];
	var length = 0;
	var sub_obj = "OBJECT";
  var groupOfLinksAndNodes = svg.append("g");
var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
var groupOfNodeElements = groupOfNodes.selectAll("g").data($scope.data1.nodes).enter().append("g")
.on("click", function(d,i){
  ok = [];
  length=d.id.length; //node length
  for(i=0;i<links_display.length;i++){
    array = links_display[i].id;
    src_array =array.slice(0,length);
    if(d.id ==src_array){
      sub_obj = "SUBJECT";
      break;
    }
      else {
        sub_obj = "OBJECT";
      }
}
for(i=0;i<links_display.length;i++){
  array = links_display[i].id;
  src_array =array.slice(0,length);
  if(d.id ==src_array){
    ok.push(links_display[i])
  }

}
// document.getElementById('parag0').innerHTML ="";

    document.getElementById('para').innerHTML = d.id;
    document.getElementById('para1').innerHTML = d.id+ " is a/an "+ "<b>"+sub_obj+"</b>";

    if(flag!=0)
    for(i=0;i<ok.length;i++){
      var parent = document.getElementById("divpara1");
      parent.innerHTML = "";

    }


    for(i=0;i<ok.length;i++){
      para = document.createElement("md-card");
      node = document.createTextNode(ok[i].source.id+ " " +ok[i].relation+" " + ok[i].target.id);
      para.appendChild(node);

      element = document.getElementById("divpara1");
      element.appendChild(para);

      element1 = document.getElementById("divpara");
      element1.appendChild(element);

      flag++;

    }

  })
        .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)

        )

        .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)

        )


groupOfNodeElements.append("circle")
  .attr("r", 30)
  .attr("fill", function(d) { return color(d.group); })
groupOfNodeElements.append("text")
  .text(function(d) {return d.id;});

var link = groupLinks
  .selectAll("path")
  .data($scope.data1.links)
  .enter().append("path")

  simulation
    .nodes($scope.data1.nodes)
    .on("tick", ticked);
  simulation
    .force("link")
    .links(  $scope.data1.links)
var nodeLabels = groupOfNodes
  .selectAll("text")
  .data($scope.data1.nodes)
  .enter().append("text")
  .text(function(d) { return d.value; })
  .attr("text-anchor","middle")
// var linkLabels = groupLinks
// 	.selectAll("text")
// 	.data(graph1.links)
// 	.enter().append("text")
// 	.text(function(d) { return d.relation })
// 	.attr("text-anchor","middle")

  function ticked() {

    link.attr("d", function(d) {
      dx = d.target.x - d.source.x;
      dy = d.target.y - d.source.y;
      dr = Math.sqrt(dx*dx + dy*dy);
      return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
    })


  // link
  // 	.attr("x1", function(d) {return d.source.x;})
  // 	.attr("y1", function(d) {return d.source.y;})
  // 	.attr("x2", function(d) {return d.target.x;})
  // 	.attr("y2", function(d) {return d.target.y;})
  groupOfNodes
    .selectAll("circle")
    .attr("cx", function(d) {return d.x;})
    .attr("cy", function(d) {return d.y;})
  groupOfNodes
    .selectAll("text")
    .attr("x", function(d) { return d.x - 20 })
    .attr("y", function(d) { return d.y; });
  // linkLabels
  // 	.attr("x", function(d) { return (d.source.x + d.target.x) / 2; })
  // 	.attr("y", function(d) { return (d.source.y + d.target.y) / 2; })
  nodeLabels
    .attr("x",function(d) {return d.x})
    .attr("y",function(d) {return d.y})
}

//graphone

function dragstarted(d) {
if (!d3.event.active) simulation.alphaTarget(0.3).restart();
d.fx = d.x;
d.fy = d.y;
}

function dragged(d) {
d.fx = d3.event.x;
d.fy = d3.event.y;
}

function dragended(d) {
// if (!d3.event.active) simulation.alphaTarget(0);
// d.fx = null;
// d.fy = null;
d.fixed = true;
// simulation.restart();
}

        });

};







  //search_function_end


//terms
$scope.term=function(s){
  $scope.display_terms = " ";
    $scope.shows1=true;
  $scope.shows=false;
  $scope.terms = [];
  console.log(s);
  $http.get("http://localhost:4000/nodes?id_like=" + s)
                   .success(function (data, status, headers, config) {
                    for(i=0;i<data.length;i++)
                    if(data[i].id.charAt(0)==s)
                        $scope.terms.push(data[i].id);
                    if($scope.terms == null)
                      $scope.display_terms = "No data starting with ";
                      }).
                     error(function(data, status, headers, config) {});
}

$scope.displayTerm = function(term){
  $scope.text = term;
  //////
  for(i=0;i<$scope.data.nodes.length;i++)
  {
    if($scope.text.toLowerCase()==($scope.data.nodes[i].id.toLowerCase() ))
    {
      $scope.grp=$scope.data.nodes[i].group;
    }//if_end
  }//for_end
      $http.get('http://localhost:4000/nodes?group='+$scope.grp)
       .success(function (data, status, headers, config) {

            $scope.data1.nodes = data;


             });
      $http.get('http://localhost:4000/links?id_like='+$scope.text)
        .success(function (data, status, headers, config) {
          $scope.data1.links = data;



  var foo = d3.select("#graph");
  foo.remove();

  var svg = d3.select("#linkgraph"),
  width = +svg.attr("width"),
  height = +svg.attr("height");


  var color = d3.scaleOrdinal(d3.schemeCategory20);

  var simulation = d3.forceSimulation()
  .force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
  .force("collision", d3.forceCollide().radius(30))
  .force("gravity",d3.forceManyBody().strength(30))
  .force("center", d3.forceCenter(width/ 2, height / 2));
  // console.log($scope.data1.nodes);
  var groupOfLinksAndNodes = svg.append("g");
  var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
  var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
  var groupOfNodeElements = groupOfNodes.selectAll("g").data($scope.data1.nodes).enter().append("g")


        .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)

        )


  groupOfNodeElements.append("circle")
  .attr("r", 30)
  .attr("fill", function(d) { return color(d.group); })
  groupOfNodeElements.append("text")
  .text(function(d) {return d.id;});

  var link = groupLinks
  .selectAll("path")
  .data($scope.data1.links)
  .enter().append("path")

  simulation
    .nodes($scope.data1.nodes)
    .on("tick", ticked);
  simulation
    .force("link")
    .links(  $scope.data1.links)
  var nodeLabels = groupOfNodes
  .selectAll("text")
  .data($scope.data1.nodes)
  .enter().append("text")
  .text(function(d) { return d.value; })
  .attr("text-anchor","middle")
  // var linkLabels = groupLinks
  // 	.selectAll("text")
  // 	.data(graph1.links)
  // 	.enter().append("text")
  // 	.text(function(d) { return d.relation })
  // 	.attr("text-anchor","middle")

  function ticked() {

    link.attr("d", function(d) {
      dx = d.target.x - d.source.x;
      dy = d.target.y - d.source.y;
      dr = Math.sqrt(dx*dx + dy*dy);
      return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
    })


  // link
  // 	.attr("x1", function(d) {return d.source.x;})
  // 	.attr("y1", function(d) {return d.source.y;})
  // 	.attr("x2", function(d) {return d.target.x;})
  // 	.attr("y2", function(d) {return d.target.y;})
  groupOfNodes
    .selectAll("circle")
    .attr("cx", function(d) {return d.x;})
    .attr("cy", function(d) {return d.y;})
  groupOfNodes
    .selectAll("text")
    .attr("x", function(d) { return d.x - 20 })
    .attr("y", function(d) { return d.y; });
  // linkLabels
  // 	.attr("x", function(d) { return (d.source.x + d.target.x) / 2; })
  // 	.attr("y", function(d) { return (d.source.y + d.target.y) / 2; })
  nodeLabels
    .attr("x",function(d) {return d.x})
    .attr("y",function(d) {return d.y})
  }

  //graphone

  function dragstarted(d) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d.fx = d.x;
  d.fy = d.y;
  }

  function dragged(d) {
  d.fx = d3.event.x;
  d.fy = d3.event.y;
  }

  function dragended(d) {
  // if (!d3.event.active) simulation.alphaTarget(0);
  // d.fx = null;
  // d.fy = null;
  d.fixed = true;
  // simulation.restart();
  }

        });




  /////
}



$scope.$on("capture",function(event,args){
  var obj = {};
  var a = ($scope.data.nodes[$scope.data.nodes.length-1].group)+1;

     obj['id']=args.src, obj['group']= a
    $http.post("http://localhost:4000/nodes", obj).
    success(function(data, status, headers, config) {
    }).
   error(function(data, status, headers, config) {});

   var obj1 = {};
    obj1['id']=args.tar, obj1['group']= a
    $http.post("http://localhost:4000/nodes", obj1).
    success(function(data, status, headers, config) {
    }).
   error(function(data, status, headers, config) {});

   //links add
   var obj2 = {};
    obj2['source']=args.src, obj2['target']= args.tar, obj2['value']=1, obj2['relation']=args.rel,obj2['id']=args.src+args.tar
     $http.post("http://localhost:4000/links", obj2).
     success(function(data, status, headers, config) {
       console.log(data);
     }).
    error(function(data, status, headers, config) {});
    window.location.reload();
//links add
});

//del broadcast
$scope.$on("del_capture",function(event,args){
$scope.grp=0;
$scope.sidentifier=0;
$scope.tidentifier=0;
$scope.arr = [];
$scope.del_terms = {};
  //for getting group
      for(i=0;i<$scope.data.nodes.length;i++){
        if((args.delf) == ($scope.data.nodes[i].id)){
             $scope.grp = $scope.data.nodes[i].group;
           }
           else{
             $scope.display_msg = " No data available !! ";
           }
        }//6 times
       $http.get('http://localhost:4000/nodes?group_like='+$scope.grp)
       .success(function (data, status, headers, config) {
         $scope.grp_terms = data;
         for(j=0;j<$scope.grp_terms.length;j++)
               $http.delete("http://localhost:4000/nodes/"+$scope.grp_terms[j].id);
       });

      //  $http.delete("http://localhost:4000/nodes/"+args.delf);
       $http.get('http://localhost:4000/links?id_like='+args.delf)
                  .success(function (data, status, headers, config) {
                    $scope.del_terms = data;
                    for(j=0;j<$scope.del_terms.length;j++)
                          $http.delete("http://localhost:4000/links/"+$scope.del_terms[j].id);
                  });
                    window.location.reload();
    });
//del_end
$scope.$on("edit_capture",function(event,args){
  for(i=0;i<$scope.data.nodes.length;i++){
    if(args.sub==($scope.data.nodes[i].id))
    {
      console.log("hi");
        var obj1 = {"property": args.sub_pro};
        $http.patch("http://localhost:4000/nodes/"+args.sub, obj1).
        success(function(data, status, headers, config) {
          console.log(data);
        }).
       error(function(data, status, headers, config) {});
     }
   }
});
});

mindMap.controller('DialogController', function($scope, $mdDialog, $rootScope) {
  $scope.searchText = "";
  $scope.a =0;
  $scope.edit_show = false;
  $scope.Person = [];
  $scope.selectedItem = [];
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.show = false;
  $scope.show1 = false;
  $scope.showsearch=false;
  $scope.msg = "";
  $scope.flag=0;
  $scope.index=[];
  $scope.filter_show = true;
  $scope.data1 = {};
  $scope.data = {};
  $scope.relations = [
          "sub concept of",
          "example of",
          "related"
      ];
//adding more controls
$scope.rows = []; // declared rows and assigned a empty row to the scope
$scope.add_more = function () {
    $scope.a++;
    $scope.rows.push({
        subject: 'sub'+$scope.a,
        object: 'obj'+$scope.a,
        relation: 'rel'+$scope.a
    });
};
//end
    $scope.hide = function() {
      $mdDialog.hide();
    };
    $scope.cancel = function() {
      $mdDialog.cancel();
    };
$scope.answer = function(src1,tar1,rel1) {
$rootScope.$broadcast("capture", {
  src:src1, tar:tar1, rel:rel1
  })
  $mdDialog.cancel();
};
// delete function
$scope.del_func = function(del) {
$rootScope.$broadcast("del_capture", {
  delf : del
})
  $mdDialog.cancel();
};
//swap function
    $scope.swap = function(s_label,o_label){
      $scope.sub_label = o_label;
      $scope.obj_label = s_label;
    };
    $scope.swap1 = function(s_label,o_label,rel){
      $scope.sub1 = o_label;
      $scope.obj1 = s_label;
    };
//swap_function end

//edit_fun
$scope.edit_fun = function(edit){
    $scope.edit_show = true;
}
$scope.edit_change = function(sub,sub_pro,sub_pro){
  $rootScope.$broadcast("edit_capture", {
    sub : sub, sub_pro : sub_pro, sub_pro:sub_pro
  })
    $mdDialog.cancel();
}
});
