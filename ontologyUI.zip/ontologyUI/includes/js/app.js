var mindMap = angular.module('mindMap',['ngMaterial']);

mindMap.factory('GetNameService', function ($http,$q)
{
    return {
        getName: function(str) {
        var url = "http://localhost:4000/nodes?id_like="+str;
            return $http.get(url)
                .then(function(response) {
                    if (typeof response.data === 'object')
                        return response.data;
                     else
                        return $q.reject(response.data);

                }, function(response) {
                        return $q.reject(response.data);
                });
        }
    };
});

mindMap.service('GetNodeService', function ($http,$q)
{
        this.getNodes = function() {
        var url = "http://localhost:4000/nodes";
            return $http.get(url)
        }
        this.getLinks = function() {
        var url = "http://localhost:4000/links";
            return $http.get(url)
        }
        this.getNodesGroup = function(s,text) {
        var url = "http://localhost:4000/nodes?"+s+text;
            return $http.get(url)
        }
        this.getLinksId = function(id) {
        var url = "http://localhost:4000/links?id_like="+id;
            return $http.get(url)
        }
});
mindMap.service('PostNodeService', function ($http,$q)
{
        this.postNodes = function(obj) {
        var url = "http://localhost:4000/nodes";
            return $http.post(url,obj)
        }
        this.postLinks = function(obj) {
        var url = "http://localhost:4000/links";
            return $http.post(url,obj)
        }
});
mindMap.service('DeleteNodeService', function ($http,$q)
{
        this.deleteNodes = function(id) {
        var url = "http://localhost:4000/nodes";
            return $http.delete(url,id)
        }
        this.deleteLinks = function(id) {
        var url = "http://localhost:4000/links";
            return $http.delete(url,id)
        }
});

mindMap.controller('graphCtrl', function($scope, $mdDialog, $rootScope, $http,GetNameService, GetNodeService, PostNodeService, DeleteNodeService) {
    $scope.searchText = "";
    $scope.shows = true;
    $scope.searchGraphShow = false;
    $scope.alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    $scope.selectedItem = [];
    $scope.isDisabled = false;
    $scope.noCache = false;
    $scope.show = false;
    $scope.show1 = false;
    $scope.showsearch=false;
    $scope.msg = "";
    $scope.flag=0;
    $scope.index=[];
    $scope.filter_show = true;
    $scope.data1 = {"nodes":[{"id":"eee"},{"id":"fff"}],"links":[{"source":"eee","target":"fff","id":"eeefff","value":"1"}]};
    $scope.data = {};

    $scope.selectedItemChange = function (item) {
        if ($scope.selectedItem){
          $scope.text=$scope.selectedItem.id;
          console.log($scope.text);
        }
      }
    $scope.searchTextChange = function (str) {
        return GetNameService.getName(str);
    }

    $scope.showTabDialog = function(ev) {
    $mdDialog.show({
     controller:  'DialogController',
     templateUrl: 'includes/views/tab.html',
     parent: angular.element(document.body),
     targetEvent: ev,
     clickOutsideToClose: true
    })};

    $scope.showTabEditDialog = function(ev) {
    $mdDialog.show({
     controller:  'EditDialogController',
     templateUrl: 'includes/views/edit_tab.html',
     parent: angular.element(document.body),
     targetEvent: ev,
     clickOutsideToClose: true
    })};

    GetNodeService.getNodes()
               .success(function (data, status, headers, config) {
                  $scope.data.nodes = data;
               });

    GetNodeService.getLinks()
                .success(function (data, status, headers, config) {
                   $scope.data.links = data;
                });

$scope.graph = function(){
    var foo = d3.select("#searchedGraph");
    foo.remove();
    $scope.searchGraphShow = true;
    $scope.shows1 = false;
    $scope.src = "";
    $scope.shows = true;
    $scope.graph2_show = true;
      for(i=0;i<$scope.data.nodes.length;i++)
      {
        if($scope.text.toLowerCase()==($scope.data.nodes[i].id.toLowerCase() ))
          $scope.grp=$scope.data.nodes[i].group;
      }//for_end
          // $http.get('http://localhost:4000/nodes?group='+$scope.grp)
          GetNodeService.getNodesGroup("group_like=",$scope.grp)
           .success(function (data, status, headers, config) {
                $scope.data1.nodes = data;

                for(i=0;i<$scope.data.links.length;i++){
                  for(j=0;j<$scope.data1.nodes.length;j++)
                  if($scope.data.links[i].source==$scope.data1.nodes[j].id)
                    $scope.src = $scope.data.links[i].source;
                } console.log($scope.src);

                // $http.get('http://localhost:4000/links?id_like='+$scope.src)
                GetNodeService.getLinksId($scope.src)
                  .success(function (data, status, headers, config) {
                    $scope.data1.links=data;
                    drawgraph("graphDisplay");
                    });

                 });

};//search_function_end

//terms
$scope.term=function(s){
  $scope.display_terms = " ";
  $scope.shows1=true;
  $scope.shows=false;
  $scope.terms = [];
  $http.get("http://localhost:4000/nodes?id_like=" + s)
                   .success(function (data, status, headers, config) {
                    for(i=0;i<data.length;i++)
                    if(data[i].id.charAt(0)==s)
                        $scope.terms.push(data[i].id);
                    if($scope.terms == null)
                      $scope.display_terms = "No data starting with ";
                      }).
                     error(function(data, status, headers, config) {});
}

$scope.displayTerm = function(term){
  $scope.text = term;
  for(i=0;i<$scope.data.nodes.length;i++){
    if($scope.text.toLowerCase()==($scope.data.nodes[i].id.toLowerCase() ))
      $scope.grp=$scope.data.nodes[i].group;
    }
    // $http.get('http://localhost:4000/nodes?group='+$scope.grp)
      GetNodeService.getNodesGroup("group=",$scope.grp)
     .success(function (data, status, headers, config) {
          $scope.data1.nodes = data;

          for(i=0;i<$scope.data.links.length;i++){
            for(j=0;j<$scope.data1.nodes.length;j++)
            if($scope.data.links[i].source==$scope.data1.nodes[j].id)
              $scope.src = $scope.data.links[i].source;
          } console.log($scope.src);

          $http.get('http://localhost:4000/links?id_like='+$scope.src)
            .success(function (data, status, headers, config) {
              $scope.data1.links=data;
              drawgraph("graphtermsDisplay");
              });

           });

  }//display_term end

                    <!-- broadcasting among controllers-->

$scope.$on("capture",function(event,args){
    var obj = {};
    var a = ($scope.data.nodes[$scope.data.nodes.length-1].group)+1;

    obj['id']=args.src, obj['group']= a
    // $http.post("http://localhost:4000/nodes", obj).
    PostNodeService.postNodes(obj)
    .success(function(data, status, headers, config) {
    }).
    error(function(data, status, headers, config) {});

    var obj1 = {};
    obj1['id']=args.tar, obj1['group']= a
    PostNodeService.postNodes(obj1)
    .success(function(data, status, headers, config) {
    }).
    error(function(data, status, headers, config) {});

 //links add
   var obj2 = {};
    obj2['source']=args.src, obj2['target']= args.tar, obj2['value']=1, obj2['relation']=args.rel,obj2['id']=args.src+args.tar
    PostNodeService.postLinks(obj2)
   .success(function(data, status, headers, config) {
   }).
  error(function(data, status, headers, config) {});
  window.location.reload();

});

//del broadcast
$scope.$on("del_capture",function(event,args){
$scope.grp=0;
$scope.sidentifier=0;
$scope.tidentifier=0;
$scope.arr = [];
$scope.del_terms = {};
  //for getting group
      for(i=0;i<$scope.data.nodes.length;i++){
        if(args.delf == $scope.data.nodes[i].id)
             $scope.grp = $scope.data.nodes[i].group;
           else
             $scope.display_msg = " No data available !! ";
        }
       $http.get('http://localhost:4000/nodes?group_like='+$scope.grp)
        // GetNodeService.getNodesGroup("group_like=",$scope.grp)
       .success(function (data, status, headers, config) {
         $scope.grp_terms = data;
         for(j=0;j<$scope.grp_terms.length;j++)
          // DeleteNodeService.deleteNodes($scope.grp_terms[j].id)
               $http.delete("http://localhost:4000/nodes/"+$scope.grp_terms[j].id);


       $http.get('http://localhost:4000/links?id_like='+args.delf)
      // GetNodeService.getLinksId("id_like=",args.delf)
                  .success(function (data, status, headers, config) {
                    $scope.del_terms = data;
                    for(j=0;j<$scope.del_terms.length;j++)
                          $http.delete("http://localhost:4000/links/"+$scope.del_terms[j].id);
                          // DeleteNodeService.deleteLinks($scope.grp_terms[j].id)
                  });
                    window.location.reload();
    });//del_end
   });

$scope.$on("edit_capture",function(event,args){
  console.log(args.sub_pro);
  for(i=0;i<$scope.data.nodes.length;i++){
    if(args.sub==($scope.data.nodes[i].id))
    {

        var obj1 = {"property": args.sub_pro};
        $http.patch("http://localhost:4000/nodes/"+args.sub, obj1).
        success(function(data, status, headers, config) {
          console.log(data);
        }).
       error(function(data, status, headers, config) {});
     }
   }
 });
});//Controller End

mindMap.controller('DialogController', function($scope, $mdDialog, $rootScope) {
  $scope.searchText = "";
  $scope.a =0;

  $scope.Person = [];
  $scope.selectedItem = [];
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.show = false;
  $scope.show1 = false;
  $scope.showsearch=false;
  $scope.msg = "";
  $scope.flag=0;
  $scope.index=[];
  $scope.filter_show = true;
  $scope.data1 = {};
  $scope.data = {};
  $scope.relations = [
          "sub concept of",
          "example of",
          "related"
      ];
//adding more controls
$scope.rows = [];
$scope.add_more = function () {
    $scope.a++;
    $scope.rows.push({
        subject: 'sub'+$scope.a,
        object: 'obj'+$scope.a,
        relation: 'rel'+$scope.a
    });
};

    $scope.hide = function() {
      $mdDialog.hide();
    };
    $scope.cancel = function() {
      $mdDialog.cancel();
    };
    $scope.answer = function(src1,tar1,rel1) {
    $rootScope.$broadcast("capture", {
      src:src1, tar:tar1, rel:rel1
      })
      $mdDialog.cancel();
    };
    // delete function
    $scope.del_func = function(del) {
    $rootScope.$broadcast("del_capture", {
      delf : del
    })
      $mdDialog.cancel();
    };
    //swap function
      $scope.swap = function(s_label,o_label){
        $scope.sub_label = o_label;
        $scope.obj_label = s_label;
      };
      $scope.swap1 = function(s_label,o_label,rel){
        $scope.sub1 = o_label;
        $scope.obj1 = s_label;
      };

});
mindMap.controller('EditDialogController', function($scope, $mdDialog, $rootScope) {
    $scope.edit_show = false;
  //edit_fun
  $scope.edit_fun = function(edit){
      $scope.edit_show = true;
  }
  $scope.edit_change = function(sub,sub_pro,sub_pro){
    $rootScope.$broadcast("edit_capture", {
      sub : sub, sub_pro : sub_pro, sub_pro:sub_pro
    })
      $mdDialog.cancel();
  }
  });
